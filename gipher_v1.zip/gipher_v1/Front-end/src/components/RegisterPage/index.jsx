import axios from "axios";
import React, { Component } from "react";
import "./sty.css";
import {Link} from "react-router-dom";

const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);

const validateForm = (errors) => {
  let valid = true;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (valid = false)
  );
  return valid;
}

class Register extends Component {

  constructor(props) {
    super(props);
    this.state = {
      fullName: null,
      email: null,
      password: null,
      image: null,
      errors: {
        fullName: '',
        email: '',
        password: '',
        image: '',
      }
    };
  }


  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;

    switch (name) {
      case 'fullName':
        errors.fullName =
          value.length < 5
            ? 'Full Name must be 5 characters long!'
            : '';
        break;
      case 'email':
        errors.email =
          validEmailRegex.test(value)
            ? ''
            : 'Email is not valid!';
        break;
      case 'password':
        errors.password =
          value.length < 8
            ? 'Password must be 8 characters long!'
            : '';
        break;
      case 'image':
        errors.image =
          value.size > 1024 ? "File size large" : "";
        break;
      default:
        break;
    }

    this.setState({ errors, [name]: value });
  }

  formData = () => {
    const formData = new FormData();
    formData.append("fullname", this.state.fullName)
    formData.append("email", this.state.email)
    formData.append("password", this.state.password)
    formData.append("file", this.state.image)
    console.log(formData.get("file"));
    return formData;

  }

  handleSubmit = (event) => {
    event.preventDefault();
    if (validateForm(this.state.errors)) {
      axios.post(' http://localhost:8043/users/app/v1/users', this.formData(), {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
        .then(res => {
          alert("User is successfully registered");
          console.log(res.data);
        })
    } else {
      console.error('Invalid Form')
    }
  }

  render() {
    const { errors } = this.state;
    return (
      <div className='wrapper'>
        <div className='form-wrapper'>
          <h1>Register Me</h1>
          <form onSubmit={this.handleSubmit} noValidate>
            <table>
              <tbody>
                <tr>
                  <td rowSpan="2">
                    <label htmlFor="fullName">UserName</label>
                  </td>
                  <td>
                    <input type='text' name='fullName' className="form-control" onChange={this.handleChange} noValidate />
                  </td>
                </tr>
                <tr>
                  <td>
                    {errors.fullName.length > 0 &&
                      <span className='error'>{errors.fullName}</span>}
                  </td>
                </tr>
                <tr>
                  <td rowSpan="2">
                    <label htmlFor="email">Email</label>
                  </td>
                  <td>
                    <input type='email' name='email' className="form-control" onChange={this.handleChange} noValidate />
                  </td>
                </tr>
                <tr>
                  <td>
                    {errors.email.length > 0 &&
                      <span className='error'>{errors.email}</span>}
                  </td>
                </tr>
                <tr>
                  <td rowSpan="2">
                    <label htmlFor="password">Password</label>
                  </td>
                  <td>
                    <input type='password' name='password' className="form-control" onChange={this.handleChange} noValidate />
                  </td>
                </tr>
                <tr>
                  <td>
                    {errors.password.length > 0 &&
                      <span className='error'>{errors.password}</span>}
                  </td>
                </tr>
              </tbody>
            </table>
            <div className="image">
              <label htmlFor="image">User Image</label>
              <input className={errors.image.size > 0 ? "error" : null} placeholder="Upload Image" type="file"
                name="image" noValidate onChange={(e) => {
                  this.setState({ 'image': e.target.files[0] })
                  console.log(e.target.files[0]);
                }}
              />
              {errors.password.length > 0 &&
                <span className='error'>{errors.image}</span>}

            </div>
            <div className='submit'>
              <button className="btn btn-light">Register Me</button>
            </div>
            <Link style={{color:"white",float:"right"}} to="/">Home</Link>  

          </form>
        </div>
      </div>
    );
  }
}
export default Register;
