import React, { useEffect, useState } from "react";

import axios from "axios";
import "./Style.css";
import Paginate from "./Paginate";
import { useHistory } from "react-router-dom";


const Sports = () => {
	const [data, setData] = useState([]);
	const [search, setSearch] = useState("");
	const [currentPage, setCurrentPage] = useState(1);
	const [itemsPerPage, setItemsPerPage] = useState(16);
	const indexOfLastItem = currentPage * itemsPerPage;
	const indexOfFirstItem = indexOfLastItem - itemsPerPage;
	const currentItems = data.slice(indexOfFirstItem, indexOfLastItem);
	const history = useHistory();

	useEffect(() => {
		const fetchData = async () => {
			const results = await axios("https://api.giphy.com/v1/gifs/search", {
				params: {
					api_key: "ZOSCaNNHsXEbWk8upLDL04kUsiExl4BV",
					q: "sports",
					rating: "g",
					limit: 1000
				}
			});
			setData(results.data.data);
		};

		fetchData();
	}, []);

	const handleSearchChange = event => {
		setSearch(event.target.value);
	};

	const handleSubmit = async event => {
		event.preventDefault();
		const results = await axios("https://api.giphy.com/v1/gifs/search", {
			params: {
				api_key: "ZOSCaNNHsXEbWk8upLDL04kUsiExl4BV",
				q: search,
				limit: 50
			}
		});
		setData(results.data.data);
	};


	const pageSelected = pageNumber => {
		setCurrentPage(pageNumber);
	  };

	  const addFav = (gif) => {
		if (sessionStorage.getItem("token")) {
		  axios.post(`http://localhost:8043/favourites/app/v1/gifs/`,
			{
			  title: gif.title,
			  url: gif.images.fixed_height.url,
			  email: sessionStorage.getItem("email")
			},
			{
			  headers: { "Authorization": `Bearer ${sessionStorage.getItem("token")}` }
			}).then(res=>{console.log(res.data)}).then(alert("Gif added to favourites!!!"));
		}
		else{
		  history.push("/login");
		}
	  }

	return (
		<div className="container-fluid ">
		<form className="form-inline justify-content-center">
			<input type="search" className="form-control w-100 " id="form1" value={search} onChange={handleSearchChange} placeholder="Search all GIFS !!"/>
			<button onClick={handleSubmit} type="button" class="btn btn-primary"><i class="fas fa-search"></i> </button>
			</form>
			<Paginate
        pageSelected={pageSelected}
        currentPage={currentPage}
        itemsPerPage={itemsPerPage}
        totalItems={data.length}
      />
				<div className="row">
					{
						currentItems.map(gif =>
							<div key={gif.id} className="col-md-3 p-3">
								<div className="gif-card">
									<img className="img-fluid" src={gif.images.fixed_height.url} alt="sports gifs"/>
									<p>{gif.title}</p>
									<button onClick={() => { addFav(gif) }} className="btn btn-danger"><i class="fas fa-heart"></i></button>
								</div>
							</div>
						)
					}
				</div>
			</div>
	
	);
}

export default Sports;
