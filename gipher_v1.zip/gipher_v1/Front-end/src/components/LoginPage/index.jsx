import axios from "axios";
import React, { Component } from "react";
import { Link } from "react-router-dom";
import "../RegisterPage/sty.css";

class Login extends Component {

  constructor(props) {
    super(props);
    this.state = {
      email: null,
      password: null,
    };
  }

  handleSubmit = (event) => {
    event.preventDefault();
    axios.post(' http://localhost:8043/authenticate/app/v1/login',
      {
        email: this.state.email,
        password: this.state.password

      }).then(res => {
        sessionStorage.setItem("token", res.data.token);
        sessionStorage.setItem("email", this.state.email);
        console.log(res.data.token,this.state.email);
        this.props.history.push("/user");
      }).catch(e=>{
        if(e.toString().includes("400")){
          document.getElementById("message").innerText="Wrong Password!!!";
        }
        if(e.toString().includes("404")){
          document.getElementById("message").innerText="User Not Found!!!";
        }
      });
      
  }

  render() {
    return (
      <div className='wrapper'>
        <div className='form-wrapper'>
          <h1>Sign In</h1>
          <form onSubmit={this.handleSubmit} noValidate>
            <table>
              <tbody>
                <tr>
                  <td>
                    <label htmlFor="email">Email</label>
                  </td>
                  <td>
                    <input type='email' name='email' className="form-control" onChange={(e) => this.setState({ email: e.target.value })} noValidate />
                  </td>
                </tr>
                <tr>
                  <td>
                    <label htmlFor="password">Password</label>
                  </td>
                  <td>
                    <input type='password' name='password' className="form-control" onChange={(e) => this.setState({ password: e.target.value })} noValidate />
                  </td>
                </tr>
              </tbody>
            </table>
            <div className='submit'>
              <button className="btn btn-light">Login</button>
            </div>
            <p id="message" className="py-2" style={{color:"red"}}></p>
            <Link style={{color:"white",float:"right"}} to="/">Home</Link>  
          </form>
        </div>
      </div>
    );
  }
}
export default Login;
