import React, { useEffect, useState } from "react";
import "../UserProfile/style.css"
import axios from "axios";
import { Link } from "react-router-dom"
import Header from "../Header";

function UserProfile() {
  const [data, setData] = useState([]);
  const [user,setUser] = useState([]);
  const [change,setChange] = useState(false);
  useEffect(() => {
    const fetchData = async () => {
      const results = await axios(`http://localhost:8043/favourites/app/v1/gifs/${sessionStorage.getItem("email")}`,
      { headers: {"Authorization" : `Bearer ${sessionStorage.getItem("token")}`} });

      const userData = await axios(`http://localhost:8043/users/app/v1/users/${sessionStorage.getItem("email")}`);
      sessionStorage.setItem("image",userData.data.image);
      setData(results.data);
      setUser(userData.data);
      setChange(true);
    };

    fetchData();
  },[change]);
  return (
    <div>
      <Header/>
      <section class="profile">
        <header class="header">
          <div class="details">
            <img src={`data:image/jpeg;base64, ${user.image}`} alt="user" class="profile-pic"></img>
            <h1 className="display-4 p-2 m-0">{user.name}</h1>
            <div class="email">
              <h3 className="display-6">{user.email}</h3>
            </div>
            <div class="edit">
              <button className="btn btn-light"><Link to="/edit">Edit</Link></button>      
            </div>
          </div>
        </header>
      </section>
      <div className="container-fluid fav-head">
          <h1>My Favourites</h1>
      </div>
      <div className="container ">
        <div className="row">
          {
            data.map(gif =>
              <div key={gif.id} className="col-md-4 p-2">
                <div className="gif-card">
                  <img className="img-fluid" src={gif.url} alt="favourites"/>
                  <p>{gif.title}</p>
                </div>
              </div>
            )
          }
        </div>
      </div>
    </div>
  )
}

export default UserProfile
