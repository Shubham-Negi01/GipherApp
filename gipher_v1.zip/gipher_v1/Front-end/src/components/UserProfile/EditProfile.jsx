import axios from "axios";
import React, {Component} from "react";
import {withRouter} from "react-router-dom";
import "../RegisterPage/sty.css";
import Header from "../Header";

const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);
  
const validateForm = (errors) => {
  let valid = true;
  Object.values(errors).forEach(
    (val) => val.length > 0 && (valid = false)
  );
  return valid;
}

class UserProfile extends Component {
  
  constructor(props) {
    super(props);
    this.state = {
      fullName: null,
      email: null,
      password: null,
      image:null,
      errors: {
        fullName: '',
        email: '',
        password: '',
        image :'',
      }
    };
  }


  handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    let errors = this.state.errors;

    switch (name) {
      case 'fullName': 
        errors.fullName = 
          value.length < 5
            ? 'Full Name must be 5 characters long!'
            : '';
        break;
      case 'email': 
        errors.email = 
          validEmailRegex.test(value)
            ? ''
            : 'Email is not valid!';
        break;
      case 'password': 
        errors.password = 
          value.length < 8
            ? 'Password must be 8 characters long!'
            : '';
        break;
        case 'image':
          errors.image=
          value.size> 1024? "File size large":"";
          break;
      default:
        break;
    }

    this.setState({errors, [name]: value});
  }

  formData = ()=> {
    const formData = new FormData();
    formData.append("fullname",this.state.fullName)
    formData.append("email",sessionStorage.getItem("email"))
    formData.append("password",this.state.password)
    formData.append("file",this.state.image)
    return formData;
   
  }

  handleSubmit = (event) => {
    event.preventDefault();
    if(validateForm(this.state.errors)) {
      axios.put('http://localhost:8043/users/app/v1/users',this.formData(),{
        headers:{
          'Content-Type':'multipart/form-data'
        }})
        .then(res => {
          console.log(res.data);
        }).then( this.props.history.push("/user"));
    }else{
      console.error('Invalid Form')
    }
  }

  render() {
    const { errors } = this.state;
    return (
      <div>
      <Header/>
      <div className='wrapper'>
        <div className='form-wrapper'>
          <h1>Edit Profile</h1>
          <form onSubmit={this.handleSubmit} noValidate>
            <table>
              <tbody>
                <tr>
                  <td rowSpan="2">
                    <label htmlFor="fullName">UserName</label>
                  </td>
                  <td>
                    <input type='text' name='fullName' className="form-control" onChange={this.handleChange} noValidate />
                  </td>
                </tr>
                <tr>
                  <td>
                    {errors.fullName.length > 0 &&
                      <span className='error'>{errors.fullName}</span>}
                  </td>
                </tr>
                <tr>
                  <td rowSpan="2">
                    <label htmlFor="email">Email</label>
                  </td>
                  <td>
                    <input type='email' name='email' value={sessionStorage.getItem("email")} className="form-control" onChange={this.handleChange} noValidate disabled/>
                  </td>
                </tr>
                <tr>
                  <td>
                    {errors.email.length > 0 &&
                      <span className='error'>{errors.email}</span>}
                  </td>
                </tr>
                <tr>
                  <td rowSpan="2">
                    <label htmlFor="password">Password</label>
                  </td>
                  <td>
                    <input type='password' name='password' className="form-control" onChange={this.handleChange} noValidate />
                  </td>
                </tr>
                <tr>
                  <td>
                    {errors.password.length > 0 &&
                      <span className='error'>{errors.password}</span>}
                  </td>
                </tr>
              </tbody>
            </table>
            <div className="image">
              <label htmlFor="image">User Image</label>
              <input className={errors.image.size > 0 ? "error" : null} placeholder="Upload Image" type="file"
                name="image" noValidate onChange={(e) => {
                  this.setState({ 'image': e.target.files[0] })
                  console.log(e.target.files[0]);
                }}
              />
              {errors.password.length > 0 &&
                <span className='error'>{errors.image}</span>}

            </div>
            <div className='submit'>
              <button className="btn btn-light">Edit</button>
            </div>
          </form>
        </div>
      </div>
      </div>
    );
  }
}
export default UserProfile;
