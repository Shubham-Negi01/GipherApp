import React from "react";
import { Route, Switch } from "react-router-dom";

import Home from "../Home";
import Header from "../Header"
import Entertainment from "../Entertainment";
import Sports from "../Sports";
import Reaction from "../Reaction";
import Stickers from "../Strickers";

const LandingPage = (props) => {
    const {match} = props
  return (
    <div>
      <Header />
      <Switch>
        <Route exact path={`${match.url}`} component={Home} />
        <Route  path={`${match.url}reactions`}  component={Reaction} />
        <Route  path={`${match.url}entertainment`} component={Entertainment} />
        <Route  path={`${match.url}sports`} component={Sports} />
        <Route  path={`${match.url}stickers`} component={Stickers} />
      </Switch>
    </div>
  );
};

export default LandingPage;
