import React from "react";
import { Link } from "react-router-dom";
import logo from "../assests/logo.png";
import "./Header.css";

function Header() {

  const isLoggedIn = sessionStorage.getItem("token") ? true : false;

  const clearStorage = () => {

    sessionStorage.removeItem("email");
    sessionStorage.removeItem("token");
  }

  const showButtons = () => {
    if (isLoggedIn) {
      return (
        <div>
          <img src={`data:image/jpeg;base64, ${sessionStorage.getItem("image")}`} alt="user" className="header-pic"></img>
          <Link to="/user">
            <button button5 className="button button5">
              {sessionStorage.getItem("email")}
            </button>
          </Link>
          <Link to="/">
            <button onClick={clearStorage} button5 className="button button5">
              Logout
            </button>
          </Link>
        </div>)
    }
    else {
      return (
        <div>
          <Link to="/register">
            <button button5 className="button button5">
              Register
            </button>
          </Link>
          <Link to="/login">
            <button button5 className="button button5">
              Login
            </button>
          </Link>
        </div>
      )
    }
  }

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark ">
      <Link to="/" className="pull-left">
        <img src={logo} alt="logo"/>
      </Link>
      <button
        className="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>

      <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item">
            <Link className="nav-link" to="/reactions">
              Reactions
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/entertainment">
              Entertainment
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/sports">
              Sports
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link" to="/stickers">
              Stickers
            </Link>
          </li>
        </ul>
        {showButtons()}
      </div>
    </nav>
  );
}

export default Header;
