import React from "react";
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';



import LoginPage from "./components/LoginPage/index"
import LandingPage from "./components/LandingPage/index"
import RegisterPage from "./components/RegisterPage/index"
import UserProfilePage from "./components/UserProfile/UserProfile"
import EditProfilePage from "./components/UserProfile/EditProfile"

import "./App.css";
const App = () => {
  return (
    <div>
      <Router>
        <Switch>
          <Route path="/edit" component={EditProfilePage} />
          <Route path="/user" component={UserProfilePage} />
          <Route path="/register" component={RegisterPage} />
          <Route path="/login" component={LoginPage} />
          <Route path="/" component={LandingPage} />
        </Switch>
      </Router>
    </div>
  );
};

export default App;
