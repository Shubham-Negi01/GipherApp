package com.globallogic.favouritesservice.service;

import com.globallogic.favouritesservice.exception.GifAlreadySavedException;
import com.globallogic.favouritesservice.exception.GifNotFoundException;
import com.globallogic.favouritesservice.model.Gif;

import java.util.List;

public interface GifService {

    Gif addGif(Gif gif) throws GifAlreadySavedException;
    Gif getGif(String id) throws GifNotFoundException;
    List<Gif> getAllGifs();
    Gif deleteGif(String id) throws GifNotFoundException;
    List<Gif> getByEmail(String email);
}
