package com.globallogic.favouritesservice.controller;

import com.globallogic.favouritesservice.exception.GifAlreadySavedException;
import com.globallogic.favouritesservice.exception.GifNotFoundException;
import com.globallogic.favouritesservice.model.Gif;
import com.globallogic.favouritesservice.service.GifServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/app/v1")
public class GifController {

    private GifServiceImpl service;

    @Autowired
    public GifController(GifServiceImpl service) {
        this.service = service;
    }

    @GetMapping("/info")
    public String info(){
        return "You are at favourites service";
    }

    @GetMapping("/gifs/{emailId}")
    public ResponseEntity<List<Gif>> getGifByEmail(@PathVariable String emailId){
        return new ResponseEntity<>(service.getByEmail(emailId), HttpStatus.OK);
    }

    @GetMapping("/gifs")
    public ResponseEntity<List<Gif>> getAllGifs(){
        return new ResponseEntity<List<Gif>>(service.getAllGifs(),HttpStatus.OK);
    }

    @PostMapping("/gifs")
    public ResponseEntity<Gif> addGif(@RequestBody Gif gif) throws GifAlreadySavedException {
        return new ResponseEntity<>(service.addGif(gif),HttpStatus.CREATED);
    }

    @DeleteMapping("/gifs/{gifId}")
    public ResponseEntity<Gif> deleteGif(@PathVariable String gifId) throws GifNotFoundException {
        return new ResponseEntity<>(service.deleteGif(gifId),HttpStatus.OK);
    }

}
