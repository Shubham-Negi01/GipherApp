package com.globallogic.favouritesservice.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(value = GifAlreadySavedException.class)
    public ResponseEntity<String> handleGifAlreadySavedException(GifAlreadySavedException e){
        return new ResponseEntity<>("Gif is already saved", HttpStatus.CONFLICT);
    }

    @ExceptionHandler(value = GifNotFoundException.class)
    public ResponseEntity<String> handleGifNotFoundException(GifNotFoundException e){
        return new ResponseEntity<>("Gif not found",HttpStatus.NOT_FOUND);
    }

}
