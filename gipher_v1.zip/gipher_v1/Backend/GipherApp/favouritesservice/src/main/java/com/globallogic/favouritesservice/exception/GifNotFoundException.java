package com.globallogic.favouritesservice.exception;

public class GifNotFoundException extends Exception{
    public GifNotFoundException() {
    }
}
