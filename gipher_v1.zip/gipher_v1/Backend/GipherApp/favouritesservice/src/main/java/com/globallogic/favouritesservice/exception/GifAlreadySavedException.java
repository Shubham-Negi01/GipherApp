package com.globallogic.favouritesservice.exception;

public class GifAlreadySavedException extends Exception{

    public GifAlreadySavedException() {
    }
}
