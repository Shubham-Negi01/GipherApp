package com.globallogic.favouritesservice.service;

import com.globallogic.favouritesservice.exception.GifAlreadySavedException;
import com.globallogic.favouritesservice.exception.GifNotFoundException;
import com.globallogic.favouritesservice.model.Gif;
import com.globallogic.favouritesservice.repository.GifRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class GifServiceImpl implements GifService{

    private GifRepository repository;

    @Autowired
    public GifServiceImpl(GifRepository repository) {
        this.repository = repository;
    }

    @Override
    public Gif addGif(Gif gif) throws GifAlreadySavedException{
        Gif savedGif = repository.findByUrlAndEmail(gif.getUrl(), gif.getEmail());
        if(savedGif!=null){
            throw new GifAlreadySavedException();
        }
        gif.setId(UUID.randomUUID().toString());
        return repository.save(gif);
    }

    @Override
    public Gif getGif(String id) throws GifNotFoundException {
        Optional<Gif> gif = repository.findById(id);
        if(gif.isEmpty())
            throw new GifNotFoundException();
        return repository.findById(id).get();
    }

    @Override
    public List<Gif> getAllGifs() {
        return (List<Gif>) repository.findAll();
    }

    @Override
    public Gif deleteGif(String id) throws GifNotFoundException{
        Optional<Gif> gif = repository.findById(id);
        if(gif.isEmpty())
            throw new GifNotFoundException();
        repository.deleteById(id);
        return gif.get();
    }

    @Override
    public List<Gif> getByEmail(String email) {
        return repository.findByEmail(email);
    }
}
