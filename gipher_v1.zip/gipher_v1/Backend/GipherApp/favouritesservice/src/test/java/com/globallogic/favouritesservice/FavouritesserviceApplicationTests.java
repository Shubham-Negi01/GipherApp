package com.globallogic.favouritesservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FavouritesserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
