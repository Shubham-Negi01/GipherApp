package com.globallogic.authenticationservice.service;

import com.globallogic.authenticationservice.exception.IncorrectPasswordException;
import com.globallogic.authenticationservice.exception.UserNotFoundException;
import com.globallogic.authenticationservice.model.UserCredentials;

import java.util.Map;

public interface UserAuthService {

    Map<String,String> authenticateUser(UserCredentials user) throws UserNotFoundException, IncorrectPasswordException;
}
