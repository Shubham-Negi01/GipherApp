package com.globallogic.authenticationservice.service;

import com.globallogic.authenticationservice.exception.IncorrectPasswordException;
import com.globallogic.authenticationservice.exception.UserNotFoundException;
import com.globallogic.authenticationservice.model.UserCredentials;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Map;

@Service
public class UserAuthServiceImpl implements UserAuthService{

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private JWTTokenGeneratorImpl jwtTokenGenerator;

    @Value("${api.url}")
    private String url;

    @Override
    public Map<String, String> authenticateUser(UserCredentials userCred) throws UserNotFoundException, IncorrectPasswordException {
        String user = getProductList(userCred.getEmail());
        if(user==null)
            throw new UserNotFoundException();
        Object obj = JSONValue.parse(user);
        JSONObject actualUser = (JSONObject) obj;
        if(actualUser.get("password").equals(userCred.getPassword())){
            return jwtTokenGenerator.generateToken(userCred);
        }
        else{
            throw new IncorrectPasswordException();
        }
    }

    private String getProductList(String email) {
        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        HttpEntity <String> entity = new HttpEntity<String>(headers);
        String s=null;
        try{
            s = restTemplate.exchange("http://"+url+":9000/app/v1/users/email/"+email, HttpMethod.GET, entity, String.class).getBody();
        }catch (HttpClientErrorException e){
            System.out.println("Couldn't find user");
        }
        return s;
    }
}
