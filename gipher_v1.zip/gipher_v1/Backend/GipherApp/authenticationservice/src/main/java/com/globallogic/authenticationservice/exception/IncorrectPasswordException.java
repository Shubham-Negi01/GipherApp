package com.globallogic.authenticationservice.exception;

public class IncorrectPasswordException extends Exception{
    public IncorrectPasswordException() {
        super();
    }
}
