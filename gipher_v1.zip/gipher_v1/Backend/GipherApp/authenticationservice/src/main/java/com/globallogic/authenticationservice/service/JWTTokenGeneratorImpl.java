package com.globallogic.authenticationservice.service;

import com.globallogic.authenticationservice.model.UserCredentials;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/*
 * This class is implementing the JWTTokenGenerator interface. This class has to be annotated with
 * @Service annotation.
 * @Service indicates annotated class is a service
 * which hold business logic in the Service layer
 *
 * */
@Service
public class JWTTokenGeneratorImpl{

    /**
     * To get the property values
     */
    private String secret = "secret";

    private String message = "message";

    public Map<String, String> generateToken(UserCredentials user) {
        String jwtToken = "";
        /*
         * Generate JWT token and store in String jwtToken
         */
        jwtToken = Jwts.builder()
                .setIssuer("AuthApi")
                .setSubject(user.getEmail())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + 1000000))
                .signWith(SignatureAlgorithm.HS256, secret)
                .compact();
        Map<String,String> jwtTokenMap = new HashMap<>();
        jwtTokenMap.put("token",jwtToken);
        jwtTokenMap.put("message",message);
        return jwtTokenMap;
    }
}
