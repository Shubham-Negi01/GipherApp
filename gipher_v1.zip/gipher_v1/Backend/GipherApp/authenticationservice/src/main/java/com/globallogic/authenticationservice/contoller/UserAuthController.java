package com.globallogic.authenticationservice.contoller;

import com.globallogic.authenticationservice.exception.IncorrectPasswordException;
import com.globallogic.authenticationservice.exception.UserNotFoundException;
import com.globallogic.authenticationservice.model.UserCredentials;
import com.globallogic.authenticationservice.service.UserAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/app/v1")
public class UserAuthController {

    private UserAuthService service;

    @Autowired
    public UserAuthController(UserAuthService service) {
        this.service = service;
    }

    @GetMapping("/info")
    public ResponseEntity<String> info(){
        return new ResponseEntity<>("service is working fine",HttpStatus.OK);
    }


    @PostMapping("/login")
    public ResponseEntity<?> authenticateUser(@RequestBody UserCredentials user) throws UserNotFoundException, IncorrectPasswordException {
       return new ResponseEntity<>(service.authenticateUser(user), HttpStatus.ACCEPTED);
    }
}
