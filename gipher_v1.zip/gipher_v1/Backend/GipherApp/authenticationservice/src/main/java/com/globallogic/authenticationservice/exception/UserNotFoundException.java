package com.globallogic.authenticationservice.exception;

public class UserNotFoundException extends Exception{
    public UserNotFoundException() {
        super();
    }
}
