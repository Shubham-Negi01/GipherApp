package com.globallogic.ZuulApiGateway.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class JWTFilter extends GenericFilterBean {
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        if (request.getMethod().equals("OPTIONS")) {
            response.setStatus(HttpServletResponse.SC_OK);
        }
        else {
            final String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer")) {
                throw new ServletException("Auth Header Missing");
            } else {
                final String token = authHeader.substring(7);
                final Claims payload;
                try {
                    payload = Jwts.parser().setSigningKey("secret").parseClaimsJws(token).getBody();
                } catch (JwtException e) {
                    throw new ServletException("Token Invalid");
                }
                request.setAttribute("claims",payload);
                request.setAttribute("user",payload.getSubject());
            }
        }
        filterChain.doFilter(servletRequest,servletResponse);
    }
}
