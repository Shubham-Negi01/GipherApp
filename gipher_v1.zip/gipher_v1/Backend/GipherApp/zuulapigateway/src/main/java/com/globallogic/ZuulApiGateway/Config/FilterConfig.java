package com.globallogic.ZuulApiGateway.Config;

import com.globallogic.ZuulApiGateway.filter.JWTFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.GenericFilterBean;

@Configuration
public class FilterConfig {

    public static final String API_URL = "/favourites/app/v1/*";

    @Bean
    public FilterRegistrationBean<GenericFilterBean> jwtFilter()
    {
        FilterRegistrationBean<GenericFilterBean> filterRegistrationBean = new FilterRegistrationBean<>();
        filterRegistrationBean.setFilter(new JWTFilter());
        filterRegistrationBean.addUrlPatterns(API_URL);
        return filterRegistrationBean;
    }
}
