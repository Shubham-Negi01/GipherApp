package com.globallogic.userservice.test.service;

import com.globallogic.userservice.exception.UserAlreadyExistsException;
import com.globallogic.userservice.exception.UserNotFoundException;
import com.globallogic.userservice.model.User;
import com.globallogic.userservice.repository.UserRepository;
import com.globallogic.userservice.service.UserServiceImpl;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {
    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserServiceImpl userService;
    private User user, user1;
    private List<User> userList;
    private Optional optional;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        user = new User("1", "shubham@gmail.com", "shubham", "abc","xyz");
        user1 = new User("2", "ankur@gmai.com", "ankur", "def","xyz");
        optional = Optional.of(user);
    }

    @AfterEach
    public void tearDown() {
        user = null;
    }

    @Test
    public void givenUserToSaveThenShouldReturnSavedUser() throws UserAlreadyExistsException {
        when(userRepository.save(any())).thenReturn(user);
        assertEquals(user, userService.addUser(user));
        verify(userRepository, times(1)).save(any());
    }

    @Test
    public void givenUserToSaveThenShouldNotReturnSavedUser() {
        when(userRepository.save(any())).thenThrow(new RuntimeException());
        Assertions.assertThrows(RuntimeException.class, () -> {
            userService.addUser(user);
        });
        verify(userRepository, times(1)).save(any());
    }

    @Test
    public void givenGetAllUsersThenShouldReturnListOfAllUsers() {
        userRepository.save(user);
        //stubbing the mock to return specific data
        when(userRepository.findAll()).thenReturn(userList);
        List<User> userList1 = userService.getAllUsers();
        assertEquals(userList, userList1);
        verify(userRepository, times(1)).save(user);
        verify(userRepository, times(1)).findAll();
    }

    @Test
    public void givenUserIdThenShouldReturnRespectiveUser() throws UserNotFoundException {
        when(userRepository.findById(anyString())).thenReturn(Optional.of(user));
        User retrieved = userService.getById(user.getUserId());
        verify(userRepository, times(1)).findById(anyString());

    }

    @Test
    void givenUserIdToDeleteThenShouldReturnDeletedUser() throws UserNotFoundException {
        when(userRepository.findById(user.getUserId())).thenReturn(optional);
        User deleted = userService.deleteUser("1");
        assertEquals("1", deleted.getUserId());

        verify(userRepository, times(1)).findById(user.getUserId());
        verify(userRepository, times(1)).deleteById(user.getUserId());
    }
}
