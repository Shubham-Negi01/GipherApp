package com.globallogic.userservice.test.repository;

import com.globallogic.userservice.model.User;
import com.globallogic.userservice.repository.UserRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
@ExtendWith(SpringExtension.class)
@DataJpaTest
public class UserRepositoryIntegrationTest {
   /* @Autowired
    private UserRepository userRepository;
    private User user;

    @BeforeEach
    public void setUp() {
        user = new User();
        user.setUserId("1");
        user.setEmail("demo@gmail.com");
        user.setName("Imneet");
        user.setPassword("abc");
    }
    @AfterEach
    public void tearDown() {
        userRepository.deleteAll();
        user = null;
    }

    @Test
    public void givenUserToSaveThenShouldReturnSavedUser() {
        userRepository.save(user);
        User fetched = userRepository.findById(user.getUserId()).get();
        assertEquals("1", fetched.getUserId());
    }

    @Test
    public void givenGetAllUsersThenShouldReturnListOfAllUsers() {
        User user = new User("2", "neha@gmail.com", "neha", "def","xyz");
        User user1 = new User("3", "nihal@gmail.com", "nihal", "ghi","xyz");
        userRepository.save(user);
        userRepository.save(user1);

        List<User> blogList = (List<User>) userRepository.findAll();
        assertEquals("nihal", blogList.get(1).getName());
    }

    @Test
    public void givenUserIdThenShouldReturnRespectiveUser() {
        User user = new User("9", "shuba@gmail.com", "Shuba", "Sample","xyz");
        User user1 = userRepository.save(user);
        Optional<User> optional = userRepository.findById(user1.getUserId());
        assertEquals(user1.getUserId(), optional.get().getUserId());
        assertEquals(user1.getEmail(), optional.get().getEmail());
        assertEquals(user1.getName(), optional.get().getName());
        assertEquals(user1.getPassword(), optional.get().getPassword());
    }

    @Test
    public void givenUserIdToDeleteThenShouldReturnDeletedUser() {
        User user = new User("4", "Demo4", "Imneet", "Sample4","xyz");
        userRepository.save(user);
        userRepository.deleteById(user.getUserId());
        Optional optional = userRepository.findById(user.getUserId());
        assertEquals(Optional.empty(), optional);
    }

    */


}
