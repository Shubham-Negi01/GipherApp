package com.globallogic.userservice.service;

import com.globallogic.userservice.exception.UserAlreadyExistsException;
import com.globallogic.userservice.exception.UserNotFoundException;
import com.globallogic.userservice.model.User;
import com.globallogic.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService{

    private UserRepository repository;

    @Autowired
    public UserServiceImpl(UserRepository repository) {
        this.repository = repository;
    }

    @Override
    public User getById(String id) throws UserNotFoundException {
        Optional<User> user = repository.findById(id);
        if(user.isEmpty()){
            throw new UserNotFoundException();
        }
        return user.get();
    }

    @Override
    public List<User> getAllUsers() {
        return (List<User>) repository.findAll();
    }

    @Override
    public User addUser(User user) throws UserAlreadyExistsException {
        if(repository.existsByEmail(user.getEmail()))
            throw new UserAlreadyExistsException();
        user.setUserId(UUID.randomUUID().toString());
        return repository.save(user);
    }

    @Override
    public User deleteUser(String id) throws UserNotFoundException {
        Optional<User> deletedUser= repository.findById(id);
        if(deletedUser.isEmpty())
            throw new UserNotFoundException();
        repository.deleteById(id);
        return deletedUser.get();
    }

    @Override
    public User getByEmailId(String emailId) throws UserNotFoundException {
        User user = repository.findByEmail(emailId);
        if(user==null){
            throw new UserNotFoundException();
        }
        return user;
    }

    @Override
    public User updateUser(User user) throws UserNotFoundException{
       Optional<User> updateUser= repository.findById(user.getEmail());
        if(updateUser.isPresent()){
            user.setUserId(updateUser.get().getUserId());
            repository.save(user);
            return user;
        }
        throw new UserNotFoundException();

    }
}
