package com.globallogic.userservice.exception;

public class UserAlreadyExistsException extends Exception{
    public UserAlreadyExistsException() {
        super();
    }
}
