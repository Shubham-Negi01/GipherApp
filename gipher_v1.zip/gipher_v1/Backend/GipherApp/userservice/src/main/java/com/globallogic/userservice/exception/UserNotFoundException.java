package com.globallogic.userservice.exception;

public class UserNotFoundException extends Exception{
    public UserNotFoundException() {
        super();
    }
}
