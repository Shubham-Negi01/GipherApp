package com.globallogic.userservice.service;

import com.globallogic.userservice.exception.UserAlreadyExistsException;
import com.globallogic.userservice.exception.UserNotFoundException;
import com.globallogic.userservice.model.User;

import java.util.List;

public interface UserService {

    User getById(String Id) throws UserNotFoundException;
    List<User> getAllUsers();
    User addUser(User user) throws UserAlreadyExistsException;
    User deleteUser(String email) throws UserNotFoundException;

    User getByEmailId(String emailId) throws UserNotFoundException;
    User updateUser(User user) throws UserNotFoundException;

}
