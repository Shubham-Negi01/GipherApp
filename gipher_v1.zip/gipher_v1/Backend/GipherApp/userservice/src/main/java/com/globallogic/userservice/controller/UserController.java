package com.globallogic.userservice.controller;

import com.globallogic.userservice.exception.UserAlreadyExistsException;
import com.globallogic.userservice.exception.UserNotFoundException;
import com.globallogic.userservice.model.User;
import com.globallogic.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/app/v1")
public class UserController {

    private UserService service;

    @Autowired
    public UserController(UserService service) {
        this.service = service;
    }

    @GetMapping("/users")
    public ResponseEntity<List<User>> getAllUsers(){
        return new ResponseEntity<>(service.getAllUsers(), HttpStatus.OK);
    }

    @GetMapping("/users/{userId}")
    public ResponseEntity<User> getUser(@PathVariable String userId) throws UserNotFoundException {

        return new ResponseEntity<>(service.getById(userId),HttpStatus.OK);
    }

    @GetMapping("/users/email/{emailId}")
    public ResponseEntity<User> getUserByEmail(@PathVariable String emailId) throws UserNotFoundException {

        return new ResponseEntity<>(service.getByEmailId(emailId),HttpStatus.OK);
    }

    @PostMapping("/users")
    public ResponseEntity<User> addUser(@RequestParam("fullname") String name,
                                        @RequestParam("email") String email,
                                        @RequestParam("password") String password,
                                        @RequestParam("file")MultipartFile file) throws UserAlreadyExistsException {
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (fileName.contains("..")){
            System.out.println("error");
        }
        try {
            user.setImage(Base64.getEncoder().encodeToString(file.getBytes()));
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return new ResponseEntity<>(service.addUser(user),HttpStatus.CREATED);
    }

    @DeleteMapping("/users/{userId}")
    public ResponseEntity<User> deleteUser(@PathVariable String userId) throws UserNotFoundException {
        return new ResponseEntity<>(service.deleteUser(userId),HttpStatus.OK);
    }

    @PutMapping("/users")
    public ResponseEntity<?> updateUser(@RequestParam("fullname") String name,
                                        @RequestParam("email") String email,
                                        @RequestParam("password") String password,
                                        @RequestParam("file")MultipartFile file)  throws UserNotFoundException {
        User user = new User();
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);

        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        if (fileName.contains("..")){
            System.out.println("error");
        }
        try {
            user.setImage(Base64.getEncoder().encodeToString(file.getBytes()));
        }
        catch (IOException e){
            e.printStackTrace();
        }
        User updated = service.updateUser(user);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }
}
